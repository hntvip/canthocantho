package com.server.Tuhuynh.web.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.server.Tuhuynh.web.model.Music;
import com.server.Tuhuynh.web.service.MusicService;

@Controller
public class WebController {
	
	private MusicService ms ; 
	
	// get all Music
//	@RequestMapping(value = "/music", method = RequestMethod.GET, produces="application/json")
//	@ResponseBody
//	public List<Music> getMusics(){
//		return ms.getListMusic();
//	}
	
	// Update Music
	@RequestMapping(value = "/createmusic", method = RequestMethod.POST, produces="application/json")
	@ResponseBody
	public void createMusic(@RequestBody Music music){
		ms.saveMusic(music);
	}

	// delete Music
//	@RequestMapping(value = "/music/{name}", method = RequestMethod.DELETE, produces="application/json")
//	@ResponseBody
//	public Music removeMusic(@PathVariable("name")){
//		ms.
//	}
}
