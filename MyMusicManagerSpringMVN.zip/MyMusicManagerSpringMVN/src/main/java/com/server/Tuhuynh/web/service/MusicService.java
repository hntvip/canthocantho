package com.server.Tuhuynh.web.service;

import java.util.List;

import com.server.Tuhuynh.web.model.Music;

public interface MusicService {
	//	public List<Music> getListMusic();

	public Music saveMusic(Music music);
	// public void removeMusic(int id);
	// public void updateMusic(int id, Music ms);
}
