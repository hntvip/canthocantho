package com.server.Tuhuynh.web.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.server.Tuhuynh.web.model.Music;

@Component
public class MusicServiceImpl implements MusicService {

	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public Music saveMusic(Music ms) {
		sessionFactory.getCurrentSession().save(ms);
		return ms;
	}

//	@Override
//	@Transactional
//	public List<Music> getListMusic() {
//		return musicDAO.getListMusic();
//	}

}
