package com.server.Tuhuynh.web.service;
import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.server.Tuhuynh.web.dao.MusicDAO;
import com.server.Tuhuynh.web.model.Music;


//@Service 
//@Service
@Component
@Transactional
public class MusicServiceImpl implements MusicService {

	@Autowired
	private MusicDAO musicDAO;
	
	//@Autowired
//	private SessionFactory sessionFactory;
	
	@Override
	public void saveMusic(Music music) {
		musicDAO.save(music);
	}


	@Override
	public void deleteMusic(int id){
		musicDAO.delete(id);
	}

	@Override
	public void updateMusic(int id, Music music) {
		musicDAO.update(id, music);
	}


	@Override
	public List<Music> getAll() {
		return musicDAO.getAll();
	}


	@Override
	public Music getMusicById(int id) {
		return musicDAO.getMusicById(id);
	}

	@Override
	public List<Music> getListMusicByName(String name) {
		return musicDAO.getListMusicByName(name);
	}


	@Override
	public void deleteListMusicByConditions(String name, String genre) {
		musicDAO.deleteByConditions(name, genre);
	}


	@Override
	public List<Music> getListMusicByConditions(String name, String genre) {
		return musicDAO.getListMusicByConditions(name, genre);
	}


	@Override
	public List<Music> getListMusicByIds(List<Integer> id) {
		return musicDAO.getListMusicByManyId(id);
	}
	
	
}
