package com.server.Tuhuynh.web.dao;

import java.util.List;

import com.server.Tuhuynh.web.model.Music;

public interface MusicDAO {
	public void save(Music music);
	public List<Music> getAll();
	public void delete(int id);
	public void update(int id, Music music);
	public Music getMusicById(int id);
	public List<Music> getListMusicByName(String name);
	public void deleteByConditions(String name, String genre);
	public List<Music> getListMusicByConditions(String name, String genre);
	public List<Music> getListMusicByManyId(List<Integer> id);
}
