package com.server.Tuhuynh.web.model;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "Music")
public class Music implements Serializable {
	private static final long serialVersionUID = -191521792693069090L;

	@Id
	@Column(name = "MUSIC_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int musicId;

	@Column(name = "MUSIC_NAME")
	private String musicName;

	@Column(name = "MUSIC_GENRE")
	private String musicGenre;

	// @Column(name ="OWNER_USER_ID")
	// private int ownerId;

	public Music() {
	}

	public Music(int musicId, String musicName, String musicGenre) {
		this.musicId = musicId;
		this.musicName = musicName;
		this.musicGenre = musicGenre;
	}

	public int getMusicId() {
		return musicId;
	}

	public void setMusicId(int musicId) {
		this.musicId = musicId;
	}

	public String getMusicName() {
		return musicName;
	}

	public void setMusicName(String musicName) {
		this.musicName = musicName;
	}

	public String getMusicGenre() {
		return musicGenre;
	}

	public void setMusicGenre(String musicGenre) {
		this.musicGenre = musicGenre;
	}


}
