package com.server.Tuhuynh.web.service;


import java.util.List;

import com.server.Tuhuynh.web.model.Music;

public interface MusicService {
	//	public List<Music> getListMusic();

	public void saveMusic(Music music);
	// public void removeMusic(int id);
	// public void updateMusic(int id, Music ms);
	
	public List<Music> getAll();
	public void deleteMusic(int id);
	public void updateMusic(int id, Music music);
	public Music getMusicById(int id);
	public List<Music> getListMusicByName(String name);
	public void deleteListMusicByConditions(String name, String genre);
	public List<Music> getListMusicByConditions(String name, String genre);
	public List<Music> getListMusicByIds(List<Integer> id);
}
