package com.server.Tuhuynh.web.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.server.Tuhuynh.web.dao.MusicDAO;
import com.server.Tuhuynh.web.model.Music;


//@Service  la o service 
@Service
public class MusicServiceImpl implements MusicService {

	/// impl interface ctrl + 1
	@Autowired
	private MusicDAO musicDAO;

	@Override
	@Transactional
	public boolean saveMusic(Music music) {
		int check = musicDAO.save(music);
		if (check < 0) { // truong hop save khong thanh cong
			return false;
		} else {
			return true;// save thanh cong 
		}
	}

	@Override
	public List<Music> getAll() {
		return musicDAO.getAll();
	}
	// bam cai gi ra nhanh v
	// chut chi
	// oke 
	// qua tao lam controller giai thich nua ne
}
