package com.server.Tuhuynh.web.model;

import javax.persistence.*;

@Entity
@Table(name = "Music")
public class Music {
	@Id
	@Column(name = "MUSIC_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int musicId;

	@Column(name = "MUSIC_NAME")
	private String musicName;

	@Column(name = "MUSIC_GENRE")
	private String musicGenre;

	// @Column(name ="OWNER_USER_ID")
	// private int ownerId;

	public Music() {
	}

	public Music(int musicId, String musicName, String musicGenre) {
		this.musicId = musicId;
		this.musicName = musicName;
		this.musicGenre = musicGenre;
	}

	public int getMusicId() {
		return musicId;
	}

	public void setMusicId(int musicId) {
		this.musicId = musicId;
	}

	public String getMusicName() {
		return musicName;
	}

	public void setMusicName(String musicName) {
		this.musicName = musicName;
	}

	public String getMusicGenre() {
		return musicGenre;
	}

	public void setMusicGenre(String musicGenre) {
		this.musicGenre = musicGenre;
	}

	// tao set get
	// ctrl + alt + s
	// ctrl + d xoa 1 dong 
	// ctrl + shift + f can le trong eclipse
	// xong
	// dc chua
	//ok
	// cuoi tuan keu em j quen roi
	// hom cafe do
	// ngon 
	// muon lam que
	// no
	// muon lam do nhau det
	// kk thoi may ve di con
	// can than toi do 
	// cai duong thay ghe
	// @GeneratedValue(strategy = GenerationType.AUTO) // TU DONG TANG ID

}
