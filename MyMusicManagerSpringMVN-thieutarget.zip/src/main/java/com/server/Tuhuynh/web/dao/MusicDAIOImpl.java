package com.server.Tuhuynh.web.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.server.Tuhuynh.web.model.Music;


// @@Repository la lop dao
@Repository
public class MusicDAIOImpl implements MusicDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public Integer save(Music music) {
		int result = -1;
		Session session = this.sessionFactory.getCurrentSession();
		session.beginTransaction();
		result = (int) session.save(music);
		session.getTransaction().commit();
		return result;
	}

// truy xuat db may lam
	@Override
	public List<Music> getAll() {
		List<Music> list = new ArrayList<>();
		list.add(new Music(1,"dasda","dasdas"));
		return list;
	}

}
