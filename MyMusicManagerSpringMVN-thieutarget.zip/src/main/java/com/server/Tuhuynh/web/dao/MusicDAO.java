package com.server.Tuhuynh.web.dao;

import java.util.List;

import com.server.Tuhuynh.web.model.Music;

public interface MusicDAO {
	public Integer save(Music music);
	public List<Music> getAll();
}
