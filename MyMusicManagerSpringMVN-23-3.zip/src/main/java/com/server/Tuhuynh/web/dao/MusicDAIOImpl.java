package com.server.Tuhuynh.web.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.server.Tuhuynh.web.model.Music;


// @@Repository la lop dao
@Repository
public class MusicDAIOImpl implements MusicDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	
	public void save(Music music) {
		 sessionFactory.getCurrentSession();
	}

// truy xuat db may lam
	@Override
	public List<Music> getAll() {
		List<Music> list = new ArrayList<>();
		list.add(new Music(1,"dasda","dasdas"));
		return list;
	}

}
