package com.server.Tuhuynh.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.server.Tuhuynh.web.model.Music;
import com.server.Tuhuynh.web.service.MusicService;

@Controller
public class WebController {
	// yes xong
	@Autowired
	private MusicService musicService;

	@RequestMapping(value = "/createmusic", method = RequestMethod.POST, produces = MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Void> createMusic(@RequestBody Music music) {
		musicService.saveMusic(music);
		// save thanh cong
		// toi ve doc may cai status cua request okok thanh cong
		// chua lam dc truong fail
		// ma may hieu khong tam hieu?
//		if (check) {
//			return new ResponseEntity<>(HttpStatus.OK);
//		} else {
//			// that baoi
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
		return new ResponseEntity<Void>( HttpStatus.OK );
	}

	// tao muon tra 1 list music ne
	@RequestMapping(value = "/music", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Music>> getAll() {
		return new ResponseEntity<>(musicService.getAll(), HttpStatus.OK);
	}

}
