package com.server.Tuhuynh.web.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.server.Tuhuynh.web.dao.MusicDAO;
import com.server.Tuhuynh.web.model.Music;

public class MusicServiceImpl implements MusicService {
	private MusicDAO musicDAO;

	public void setMusicDAO(MusicDAO musicDAO) {
		this.musicDAO = musicDAO;
	}

	@Override
	@Transactional
	public void saveMusic(Music ms) {
		musicDAO.saveMusic(ms);
	}


}
