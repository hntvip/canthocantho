package com.server.Tuhuynh.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.server.Tuhuynh.web.model.Music;

@Controller
public class WebController {
	private static final Music ms= new Music();
	@RequestMapping(value = "/getIndex", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public void getIndex() {
		System.out.println(ms.getName()+ " "+ ms.getGenre());
	}
	@RequestMapping(value = "/getIndex", method = RequestMethod.POST, produces="application/json")
	@ResponseBody
	public Music postIndex(){
		return new Music("Bai Hat So 1", "Nhac Tre");
	}
//	@RequestMapping(value = "/getIndex/{name}", method = RequestMethod.DELETE, produces="application/json")
//	@ResponseBody
//	public Music deleteIndex(@PathVariable("name")){
//		ms.
//	}
}
