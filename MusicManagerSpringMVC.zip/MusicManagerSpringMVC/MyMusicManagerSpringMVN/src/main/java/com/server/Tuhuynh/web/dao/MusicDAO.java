package com.server.Tuhuynh.web.dao;

import java.util.List;

import com.server.Tuhuynh.web.model.Music;



public interface MusicDAO  {
	
	public List<Music> getListMusic();

//	public void removeMusic(int id);
	
	public void saveMusic(Music music);
	
//	public void updateMusic(int id, Music ms);
}
