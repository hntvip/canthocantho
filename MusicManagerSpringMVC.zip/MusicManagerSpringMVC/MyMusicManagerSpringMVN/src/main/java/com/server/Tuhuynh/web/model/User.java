package com.server.Tuhuynh.web.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;


// One to many

@Entity
@Table(name="USER")
public class User {
	@Id
	@Column(name ="USER_ID", unique=true, nullable=false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	
	@Column(name="USER_NAME")
	private String name;
	
	
	@OneToMany(cascade = CascadeType.ALL)
	//@JoinColumn(name="OWNER_USER_ID", referencedColumnName="USER_ID")
//	@JoinTable(name = "MANAGER_MUSIC", joinColumns = { @JoinColumn(name = "USER_ID") }, inverseJoinColumns = { @JoinColumn(name = "MUSIC_NAME") })
	@JoinColumn(name="USER_ID")
	private Set<Music> musics = new HashSet<Music>(0);
	
	
	
	public Set<Music> getMusics() {
		return this.musics;
	}
	public void setMusics(Set<Music> musics) {
		this.musics = musics;
	}

	public User(){}
	
	public User( String name) {
        this.name = name;
    }

	public User(String name, Set<Music> musics){
		this.name = name;
		this.musics= musics;
	}
	//@GeneratedValue(strategy = GenerationType.AUTO) // TU DONG TANG ID
	
	public int getId(){
		return userId;
	}
	public void setId(int musicId){
		this.userId = musicId;
	}
	
	public String getNameUser(){
		return name;
	}
	public void setNameUser(String name){
		this.name =name;
	}

	 
//	 public Set<Music> getMusic(){
//		 return this.musics;
//	 }
//	 public void setMusic(Set<Music> musics){
//		 this.musics = musics;
//	 }
	 
}


