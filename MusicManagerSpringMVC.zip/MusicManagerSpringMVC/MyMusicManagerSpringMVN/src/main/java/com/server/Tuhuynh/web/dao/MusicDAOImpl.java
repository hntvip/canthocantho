package com.server.Tuhuynh.web.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.server.Tuhuynh.web.model.Music;


public class MusicDAOImpl implements MusicDAO{
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	public void saveMusic(Music music){
		sessionFactory.getCurrentSession().save(music);
	}
	public List<Music> getListMusic() {
		return sessionFactory.getCurrentSession().createQuery("from music").list();
	}
	// delete
//	public List<Music> removeMusic() {
//		
//	}
}
