package com.server.Tuhuynh.web.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.server.Tuhuynh.web.model.Music;

public class MusicDAOImpl {
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	public void saveMusic(Music music){
		sessionFactory.getCurrentSession().save(music);
	}
}
