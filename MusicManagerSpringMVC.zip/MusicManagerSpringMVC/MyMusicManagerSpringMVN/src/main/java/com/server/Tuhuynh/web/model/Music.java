package com.server.Tuhuynh.web.model;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "Music")
public class Music{
	@Id
	@Column(name = "MUSIC_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int musicId;

	@Column(name = "MUSIC_NAME")
	private String musicName;

	@Column(name = "MUSIC_GENRE")
	private String musicGenre;
	
//	@Column(name ="OWNER_USER_ID")
//	private int ownerId;
	
	
	public Music() {
	}

	public Music(int musicId, String musicName, String musicGenre) {
		this.musicId = musicId;
		this.musicName = musicName;
		this.musicGenre = musicGenre;
	}

	public Music(String musicName, String musicGenre) {
		this.musicName = musicName;
		this.musicGenre = musicGenre;
	}

	// @GeneratedValue(strategy = GenerationType.AUTO) // TU DONG TANG ID

	public int getId() {
		return musicId;
	}

	public void setId(int musicId) {
		this.musicId = musicId;
	}

	public String getName() {
		return musicName;
	}

	public void setName(String musicName) {
		this.musicName = musicName;
	}

	public String getGenre() {
		return musicGenre;
	}

	public void setGenre(String musicGenre) {
		this.musicGenre = musicGenre;
	}



}


