@typedef {{}} can.AjaxSettings

@description The options available to be passed to [can.ajax].

@option {String} url 
@option {*} data

