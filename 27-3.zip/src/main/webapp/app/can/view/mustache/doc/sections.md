@page can.Mustache.Sections Sections
@parent can.Mustache.pages 1




## Comments

Comments, which do not appear in template output, begin a bang (!).

	<h1>My friend is {{!Brian}}</h1>

would render:

	<h1>My friend is </h1>