steal('can/util', 'can/control/route', 'can/model', 'can/view/ejs', 'can/route', function(can) {
	return can;
});