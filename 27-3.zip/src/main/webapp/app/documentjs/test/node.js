var document = require('./node');

document('documentjs', {
	markdown : ['documentjs'],
	out: 'documentjs/docs',
	index: 'DocumentJS'
});