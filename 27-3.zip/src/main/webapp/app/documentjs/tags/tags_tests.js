steal('./helpers/namer_test.js',
	'./helpers/tree_test.js',
	'./helpers/typer_test.js',
	'./helpers/typeNameDescription_test.js',
	
	'./add_test.js',
	'./function_test.js',
	'./option_test.js',
	'./param_test.js',
	'./process_test.js',
	'./property_test.js',
	'./return_test.js',
	'./typedef_test.js')
