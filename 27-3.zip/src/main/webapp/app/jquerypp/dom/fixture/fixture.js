steal('jquery', 'can/util/fixture', function($, fixture) {
	$.fixture = fixture;
})
