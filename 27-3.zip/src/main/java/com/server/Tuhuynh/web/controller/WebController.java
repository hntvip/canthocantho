package com.server.Tuhuynh.web.controller;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.server.Tuhuynh.web.model.Music;
import com.server.Tuhuynh.web.service.MusicService;

@Controller
public class WebController {
	@Autowired
	private MusicService musicService;

	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public Music createMusic(@RequestBody Music music) {
		this.musicService.saveMusic(music);
		return music;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = "application/json")
	@ResponseBody
	public void deleteMusic(@PathVariable int id) {
		this.musicService.deleteMusic(id);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT, produces = "application/json")
	@ResponseBody
	public void updateMusic(@PathVariable int id, @RequestBody Music music) {
		this.musicService.updateMusic(id, music);
	}

	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Music> getAll() {
		return musicService.getAll();
	}

	// Get By Id
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public Music getMusicById(@PathVariable int id) {
		return musicService.getMusicById(id);
	}
	// delete list of music by ids,
	// @query param.... ?GENRE=nhac

	// get By music name %like&
	@RequestMapping(value = "/music/{name}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Music> getListMusicByName(@PathVariable String name) {
		return musicService.getListMusicByName(name);
	}
	// get music by conditions
	@RequestMapping(value = "/music", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Music> getListMusicByConditions(@RequestParam(value = "name") String name,
			@RequestParam(value = "genre") String genre) {
		return musicService.getListMusicByConditions(name, genre);
	}

	// get music by many Ids
	@RequestMapping(value = "/music/getListId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Music> getMusicByIds(@RequestParam("listId") List<Integer> id) {
		return musicService.getListMusicByIds(id);
	}
	// delete by many Ids
	@RequestMapping(value = "/music/deleteListIds", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void deleteMusicByIds(@RequestParam("listId") List<Integer> id) {
		musicService.deleteMusicByIds(id);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
