package com.server.Tuhuynh.web.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.server.Tuhuynh.web.model.Music;

// @@Repository
@Repository
public class MusicDAIOImpl implements MusicDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void save(Music music) {
		Session session = this.sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.save(music);
		session.getTransaction().commit();
	}

	@Override
	public void delete(int id) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		Music music = (Music) session.createCriteria(Music.class).add(Restrictions.eq("musicId", id)).uniqueResult();

		if (music != null) {
			session.delete(music);
		}
		System.out.print("Can not delete this ID");

		session.getTransaction().commit();
	}

	@Override
	public void update(int id, Music music) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		Music ms = (Music) session.createCriteria(Music.class).add(Restrictions.eq("musicId", id)).uniqueResult();

		// Music mss = (Music) session.get(Music.class, id);
		// Music mss = (Music) session.load(theClass, id)

		ms.setMusicGenre(music.getMusicGenre());
		ms.setMusicName(music.getMusicName());
		session.update(ms);

		session.getTransaction().commit();
	}

	@Override
	public List<Music> getAll() {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Music> musics = session.createCriteria(Music.class).list();
		session.getTransaction().commit();
		System.out.print(musics);
		return musics;
	}

	@Override
	public Music getMusicById(int id) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		Music ms = (Music) session.load(Music.class, id);
		session.getTransaction().commit();
		return ms;
	}

	@Override
	public List<Music> getListMusicByName(String name) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Music> ms = session.createCriteria(Music.class).add(Restrictions.like("musicName", "%" + name + "%"))
				.list();
		session.getTransaction().commit();
		return ms;
	}

	@Override
	public void deleteByConditions(String name, String genre) {
		// select * from music where MUSIC_GENRE like "%Nhac%" and
		// MUSIC_NAME="Vi Yeu"
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Music> ls = session.createCriteria(Music.class).add(Restrictions.eq("musicName", name))
				.add(Restrictions.eq("musicGenre", genre)).list();
		for (Music ob : ls) {
			session.delete(ob);
			System.out.print(ob.getMusicGenre());
			System.out.print("-------------Hello-------");
		}
		session.getTransaction().commit();
	}

	@Override
	public List<Music> getListMusicByConditions(String name, String genre) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Music> ls = session.createCriteria(Music.class).add(Restrictions.eq("musicName", name))
				.add(Restrictions.eq("musicGenre", genre)).list();
		session.getTransaction().commit();
		return ls;

	}

	@Override
	public List<Music> getListMusicByManyId(List<Integer> id) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Music> ls = session.createCriteria(Music.class).add(Restrictions.in("musicId", id)).list();
		return ls;
	}

	@Override
	public void deleteMusicByIds(List<Integer> id) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Music> ls = session.createCriteria(Music.class).add(Restrictions.in("musicId", id)).list();
		for (Music ob : ls) {
			session.delete(ob);
		}
		
		session.getTransaction().commit();
	}

}





























