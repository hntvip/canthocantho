package myMusicApplication;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.impl.CriteriaImpl.Subcriteria;


public class Function { 
	
	// Liet Ke Danh sach Bai Hat Theo USER
//	public Music findMusicByUser(String userName){
//		Session session = (Session) em.getDelagate();
//    }
//	
    // Nhap Music Liet Ke Danh Sach nguoi so Huu
    public static void findForeignKeyName(String musicName){
    	SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		try{
			session.beginTransaction();

			Subcriteria cr2= (Subcriteria) session.createCriteria(User.class)
									.createCriteria("musics","ms")
									.add(Restrictions.eq("ms.musicName",musicName));
				
			List<User> results2 = cr2.list();
			System.out.println("--------------------"+results2);
			for (User ms : results2){
				//System.out.println("Nguoi So Huu:"+ ms.getName());
				String mu = ms.getNameUser();
				System.out.println("Hello:--------------"+mu);
			}
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally{
			session.close();	
		}
    }
    // Nhap Music Tim Danh Sach Cac Bai hat Trung Ten
    public static void findDuplicateName(String musicName){
    	SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		try{
		session.beginTransaction();
		Criteria cr = session.createCriteria(Music.class).setFirstResult(1);

		cr.add(Restrictions.like("musicName", musicName));
		List<Music> results = cr.list();
		if (results.isEmpty()){
			System.out.print("Khong co bai trung");
		}else{
			
			for (Music ms : results){
				
				System.out.println(ms.getName());
			}
		}
		session.getTransaction().commit();
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally{
			session.close();	
		}
    }
	
    public static void findMusic(String musicName){
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		Music mb = (Music) session.get(Music.class,musicName);
		session.getTransaction().commit();
		session.close();
	}
    
	private static Music read(int id) {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();

		Music musics = (Music) session.get(Music.class, id);
		session.close();
		return musics;
	}
}
