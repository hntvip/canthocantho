package myMusicApplication;
import myMusicApplication.*;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class App {
	public static void main( String[] args )
    {
    	SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		Set<Music> musics = new HashSet<Music>();
		Set<Music> musics2 = new HashSet<Music>();
		
		Music p3 =new Music("Hoa Vang","Nhac Tre");
		Music p4 =new Music("Hoa Tim", "Nhac Xua");
		Music p5 =new Music("Ben Toi La Bien La", "Nhac Xua");
		Music p6 =new Music("Doi Thong", "Nhac Xua");
		
		musics.add(p3);
		musics.add(p4);
		musics2.add(p5);
		musics2.add(p6);

		User user = new User("Huynh ngoc tu", musics);
		User user2 = new User("Harrypotter", musics2);
		session.save(user);
		session.save(user2);
		session.getTransaction().commit();
		session.close();
		System.out.println("--------------------------------------------");
		//Function.findMusicByUser("Huynh Ngoc Tu");
		Function.findForeignKeyName("Doi Thong");
//		Function.findDuplicateName("Hoa Vang");
    }
}
