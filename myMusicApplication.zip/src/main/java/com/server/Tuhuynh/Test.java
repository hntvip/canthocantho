package com.server.Tuhuynh;

import java.util.List;

import org.hibernate.*;



public class Test {  
	public static void main(String[] args) {  
	
	    //Session session = HibernateUtil.getSession();
	    
	    //session.beginTransaction();
	    
//	    Employee e3=new Employee(1004,"Tu Huynh","Nhac tre");  
//	    e3.setId(1003);  
//	    e3.setFirstName("sonoo");  
//	    e3.setLastName("jaiswal");  
//	    MusicTable m3 = new MusicTable();
//	    MusicTable m4 = new MusicTable();
//	    m3.setName("Tao la Tui Tieo");
//	    m3.setGenre("Nhac tre");
//	    m4.setName("Tao la Tui Tieo");
//	    m4.setGenre("Nhac tre");
//	    session.save(m3);  
//	    session.save(m4);  
//	    session.getTransaction().commit();
//	    session.close();
//	    System.out.println("successfully saved");  
	    
	    MusicTable m1 = new MusicTable("Canh Dong Haong","Nhac Tre");	 
	    MusicTable m2= new MusicTable("Thuong1","Nhac Tre");	 
	    MusicTable m3= new MusicTable("Yeu Duoi","Nhac Tre");	 
	    MusicTable m4= new MusicTable("Destiny","Nhac Tre");	 
	    MusicTable m5= new MusicTable("Destiny","Nhac Tre");
	    // add music to table
		addMusic(m1);
		addMusic(m2);
		addMusic(m3);
		addMusic(m4);
		addMusic(m5);
		// update music:
//		m5.setName("Yeu Duoi");
//		m5.setGenre("Nhac Tru Tinh");
		updateMusic(m5);
		// delete Music theo ID
		//deleteMusic(m4.getId());
		findMusic(m5);
	}  
	//Function add Music to Table
		
	public static void addMusic(MusicTable e) {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		session.save(e);
		
		session.getTransaction().commit();
		session.close();
		System.out.println("Successfully created " + e.toString());
		
	}
	// update Music
	public static void updateMusic(MusicTable em) {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		MusicTable mb = (MusicTable) session.get(MusicTable.class,em.getId());
		mb.setName(em.getName());
		mb.setGenre(em.getGenre());
		
		session.getTransaction().commit();
		session.close();
		System.out.println("Successfully updated " + em.toString());
	}
	public static void findMusic(MusicTable em){
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		MusicTable mb = (MusicTable) session.get(MusicTable.class,em.getName());
		mb.setName(em.getName());
		mb.setGenre(em.getGenre());
		session.getTransaction().commit();
		session.close();
		
	}
	public static void deleteMusic(int id) {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		// load to find 
		MusicTable e = (MusicTable) session.get(MusicTable.class, id);
		session.delete(e);
		session.getTransaction().commit();
		session.close();
		System.out.println("Successfully deleted " + e.toString());
	}
}  
