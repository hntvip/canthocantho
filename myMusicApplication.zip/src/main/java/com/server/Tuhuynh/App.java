package com.server.Tuhuynh;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.impl.CriteriaImpl.Subcriteria;




public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		Set<MusicTable> musics = new HashSet<MusicTable>();
		Set<MusicTable> musics2 = new HashSet<MusicTable>();
		//Set<MusicTable> musics = new HashSet<MusicTable>();
		
//		MusicTable mt1 = new MusicTable("Bai So 3","Nhac Tre");
//		MusicTable mt2 = new MusicTable("Bai So 4","Nhac Tre");
//		musics.add(mt1);
//		musics.add(mt2);
//		UserManager userManager = new UserManager("Huynh Ngoc Tu");
//		userManager.setMusicTable(musics);

		//session.save(musics);
//		session.save(userManager);
//		session.save(mt1);
//		session.save(mt2);
		
		MusicTable p3 =new MusicTable("Hoa Vang","Nhac Tre");
		MusicTable p4 =new MusicTable("Hoa Tim", "Nhac Xua");
		MusicTable p5 =new MusicTable("Ben Toi La Bien La", "Nhac Xua");
		MusicTable p6 =new MusicTable("Doi Thong", "Nhac Xua");
		
		musics.add(p3);
		musics.add(p4);
		musics2.add(p5);
		musics2.add(p6);

		UserManager user = new UserManager("Huynh ngoc tu", musics);
		UserManager user2 = new UserManager("Harrypotter", musics2);
		session.save(user);
		session.save(user2);
		session.getTransaction().commit();
		session.close();
		findForeignKeyName("Doi Thong");
		//findDuplicateName("Hoa Vang");
    }
    // function
    
    public static void findForeignKeyName(String musicName){
    	SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		try{
			session.beginTransaction();

			Subcriteria cr2= (Subcriteria) session.createCriteria(UserManager.class)
									.createCriteria("musics","ms")
									.add(Restrictions.eq("ms.musicName",musicName));

			List<MusicTable> results2 = cr2.list();
			System.out.println("--------------------"+results2);
			for (MusicTable ms : results2){
				//System.out.println("Nguoi So Huu:"+ ms.getName());
				String mu = ms.getName();
				System.out.println("Hello:--------------"+mu);
			}
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally{
			session.close();	
		}
    }
    
    public static void findDuplicateName(String musicName){
    	SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		try{
		session.beginTransaction();
		Criteria cr = session.createCriteria(MusicTable.class).setFirstResult(1);

		cr.add(Restrictions.like("musicName", musicName));
		List<MusicTable> results = cr.list();
		if (results.isEmpty()){
			System.out.print("Khong co bai trung");
		}else{
			
			for (MusicTable ms : results){
				
				System.out.println(ms.getName());
			}
		}
		session.getTransaction().commit();
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally{
			session.close();	
		}
    }
	public static void findMusic(String musicName){
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		MusicTable mb = (MusicTable) session.get(MusicTable.class,musicName);
		session.getTransaction().commit();
		session.close();
		
	}
	private static List list(String MusicName) {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();

		//List musics = session.createQuery("SELECT M.musicName FROM MusicTable M WHERE E.musicName =: musicname").list();
		String hql = "SELECT E.musicName FROM MusicTable E WHERE E.musicName = :musicName";
		Query query = session.createQuery(hql);
		query.setParameter("musicName",MusicName);
		List results = query.list();
		session.close();
		return results;
	}
	private static MusicTable read(int id) {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();

		MusicTable musics = (MusicTable) session.get(MusicTable.class, id);
		session.close();
		return musics;
	}
}
